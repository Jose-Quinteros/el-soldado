# Configuración del respaldo en Google Sheets / Google Drive

La app del navegador no guarda credenciales de Google. Se conecta a un pequeño servicio (`Code.gs`, Google Apps Script) que corre con tu cuenta, escribe en tu carpeta de Drive y valida una clave compartida.

## 1. Carpeta de destino
1. En Google Drive creá (o elegí) la carpeta donde se guardarán las hojas.
2. Abrila y copiá su ID: es la parte final de la URL `https://drive.google.com/drive/folders/`**`ESTE_ES_EL_ID`**.

## 2. Crear el servicio
1. Entrá a https://script.google.com → **Nuevo proyecto**.
2. Borrá el contenido y pegá el código de `Code.gs`. Guardá.
3. **Configuración del proyecto → Propiedades del script → Agregar propiedad**:
   - `TOKEN`: una clave larga y aleatoria (mínimo 24 caracteres).
   - `FOLDER_ID`: el ID de la carpeta del paso 1.
4. En el editor elegí la función `autorizar` y presioná **Ejecutar**. Aceptá los permisos (Drive y Hojas de cálculo). Esto crea la hoja `Respaldo_Controles_Clasificacion` dentro de la carpeta.

## 3. Publicar
1. **Implementar → Nueva implementación → Aplicación web**.
2. *Ejecutar como*: **Yo**. *Quién tiene acceso*: **Cualquier usuario**.
3. Copiá la URL que termina en `/exec`.

> Si más adelante modificás `Code.gs`: **Implementar → Administrar implementaciones → Editar → Nueva versión**. La URL se mantiene.

## 4. Conectar la app
1. En la app: **Administración → [ GOOGLE SHEETS ]**.
2. Pegá la URL `/exec` y la clave (`TOKEN`). Dejá activado el respaldo automático.
3. **Guardar configuración** y luego **Probar conexión** (debe mostrar el nombre de tu carpeta).

## Cómo funciona
- **Respaldo automático**: al presionar *Guardar Control* el registro se guarda primero en la app y luego se envía a la hoja `Respaldo_Controles_Clasificacion`:
  - pestaña `Controles`: una fila por control (si se vuelve a guardar el mismo ID, se **actualiza** esa fila);
  - pestaña `Errores_Control`: una fila por error asociado (código, solapa, indicador, nombre, mensaje técnico).
- **Estado visible**: la columna *Respaldo* del Historial muestra ☁️ Respaldado / ⏳ Pendiente / ⚠️ Error (con el motivo al pasar el mouse). Un fallo de conexión nunca pierde datos. El botón **Reintentar respaldos pendientes** reenvía lo que falte (incluye controles anteriores a esta función).
- **Exportación integral**: en *Historial* → **Exportar historial completo a Google Sheets** crea un archivo NUEVO `Historial_Completo_Clasificacion_AAAA-MM-DD` en la carpeta (si ya existe el nombre, agrega la hora) con todos los controles guardados en la app, aun los de sesiones anteriores. No modifica ni vacía el historial. Al terminar muestra nombre, carpeta y enlace.
- Eliminar un control de la app **no** lo borra de la hoja de respaldo (queda como archivo histórico).

## Seguridad
- No hay claves privadas ni tokens de Google en el código del navegador; los permisos de Drive/Sheets los tiene solo el script.
- La URL `/exec` es accesible públicamente y se protege con la clave `TOKEN`, que cada usuario carga en su navegador (se guarda en su `localStorage`, no en el código ni en las exportaciones JSON). Quien tenga URL + clave puede escribir en la hoja: compartila solo con quienes corresponda y, si se filtra, cambiá `TOKEN` en las propiedades del script.
- Limitación de una app 100 % estática: no es posible ocultar por completo una clave a quien use la app en su navegador. Si necesitás autenticación por usuario, hay que agregar un backend propio o inicio de sesión con OAuth.
