/**
 * ASISTENTE DE ANÁLISIS CRIMINAL - MÓDULO DE LÓGICA FRONTEND
 */

document.addEventListener('DOMContentLoaded', () => {

  const form = document.getElementById('analysis-form');
  
  // Evento 1
  const inputId1 = document.getElementById('id-evento-1');
  const inputLugar1 = document.getElementById('lugar-evento-1');
  const inputPartido1 = document.getElementById('partido-evento-1');
  const inputDelito1 = document.getElementById('delito-evento-1');
  const inputFecha1 = document.getElementById('fecha-evento-1');
  const inputInfo1 = document.getElementById('info-evento-1');

  // Evento 2
  const inputId2 = document.getElementById('id-evento-2');
  const inputLugar2 = document.getElementById('lugar-evento-2');
  const inputPartido2 = document.getElementById('partido-evento-2');
  const inputDelito2 = document.getElementById('delito-evento-2');
  const inputFecha2 = document.getElementById('fecha-evento-2');
  const inputInfo2 = document.getElementById('info-evento-2');

  // Errores Evento 1
  const errorId1 = document.getElementById('error-id-evento-1');
  const errorLugar1 = document.getElementById('error-lugar-evento-1');
  const errorPartido1 = document.getElementById('error-partido-evento-1');
  const errorDelito1 = document.getElementById('error-delito-evento-1');
  const errorFecha1 = document.getElementById('error-fecha-evento-1');
  const errorInfo1 = document.getElementById('error-info-evento-1');

  // Errores Evento 2
  const errorId2 = document.getElementById('error-id-evento-2');
  const errorLugar2 = document.getElementById('error-lugar-evento-2');
  const errorPartido2 = document.getElementById('error-partido-evento-2');
  const errorDelito2 = document.getElementById('error-delito-evento-2');
  const errorFecha2 = document.getElementById('error-fecha-evento-2');
  const errorInfo2 = document.getElementById('error-info-evento-2');

  // Resultado
  const resultSection = document.getElementById('result-section');
  const outputMessage = document.getElementById('output-message');
  const btnCopy = document.getElementById('btn-copy');
  const btnReset = document.getElementById('btn-reset');
  const toast = document.getElementById('toast');

  // Restricción solo números para ID
  const restrictToNumeric = (e) => {
    e.target.value = e.target.value.replace(/\D/g, '');
  };

  inputId1.addEventListener('input', restrictToNumeric);
  inputId2.addEventListener('input', restrictToNumeric);

  // Formateador de Fecha DD/MM/AAAA
  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateStr;
  };

  // Plantilla del Mensaje Preestablecida (Única Salida)
  const buildTemplate = (data) => {
    const fecha1Fmt = formatDate(data.fecha1);
    const fecha2Fmt = formatDate(data.fecha2);

    return `SE INFORMA: El evento id “${data.id1}” (${data.delito1} - Partido de ${data.partido1} - Fecha ${fecha1Fmt}) de la “${data.lugar1}”, posee una correlación con el evento id “${data.id2}” (${data.delito2} - Partido de ${data.partido2} - Fecha ${fecha2Fmt}) de la “${data.lugar2}”; Mismos eventos generan duplicidad de personas, carátulas, entre otros ítems. Por lo cual, se procede a sacar de línea al evento id “${data.id2}” de la “${data.lugar2}”, para no generar estos inconvenientes, impulsando completar con los datos correspondientes al relato manteniendo la integridad de la información.-`;
  };

  // Validaciones
  const validateId = (value) => {
    const regex = /^[0-9]{7}$/;
    if (!value || value.trim() === '') {
      return { valid: false, message: 'El ID es obligatorio.' };
    }
    if (!regex.test(value)) {
      return { valid: false, message: 'Debe contener exactamente 7 dígitos.' };
    }
    return { valid: true, message: '' };
  };

  const validateRequired = (value, name) => {
    if (!value || value.trim() === '') {
      return { valid: false, message: `El campo ${name} es obligatorio.` };
    }
    return { valid: true, message: '' };
  };

  const updateFieldUI = (inputElement, errorElement, validationResult) => {
    const parentGroup = inputElement.closest('.form-group');
    if (validationResult.valid) {
      parentGroup.classList.remove('error');
      parentGroup.classList.add('success');
      errorElement.textContent = '';
    } else {
      parentGroup.classList.remove('success');
      parentGroup.classList.add('error');
      errorElement.textContent = validationResult.message;
    }
  };

  const clearValidationUI = (inputElement, errorElement) => {
    const parentGroup = inputElement.closest('.form-group');
    parentGroup.classList.remove('error', 'success');
    errorElement.textContent = '';
  };

  // Manejo de Generación
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const valId1 = inputId1.value.trim();
    const valLugar1 = inputLugar1.value.trim();
    const valPartido1 = inputPartido1.value.trim();
    const valDelito1 = inputDelito1.value.trim();
    const valFecha1 = inputFecha1.value;
    const valInfo1 = inputInfo1.value.trim();

    const valId2 = inputId2.value.trim();
    const valLugar2 = inputLugar2.value.trim();
    const valPartido2 = inputPartido2.value.trim();
    const valDelito2 = inputDelito2.value.trim();
    const valFecha2 = inputFecha2.value;
    const valInfo2 = inputInfo2.value.trim();

    // Validar Evento 1
    const resId1 = validateId(valId1);
    const resLugar1 = validateRequired(valLugar1, 'Fiscalía / UFI');
    const resPartido1 = validateRequired(valPartido1, 'Partido');
    const resDelito1 = validateRequired(valDelito1, 'Delito');
    const resFecha1 = validateRequired(valFecha1, 'Fecha');
    const resInfo1 = validateRequired(valInfo1, 'Información del Evento 1');

    // Validar Evento 2
    const resId2 = validateId(valId2);
    const resLugar2 = validateRequired(valLugar2, 'Fiscalía / UFI');
    const resPartido2 = validateRequired(valPartido2, 'Partido');
    const resDelito2 = validateRequired(valDelito2, 'Delito');
    const resFecha2 = validateRequired(valFecha2, 'Fecha');
    const resInfo2 = validateRequired(valInfo2, 'Información del Evento 2');

    // Actualizar UI
    updateFieldUI(inputId1, errorId1, resId1);
    updateFieldUI(inputLugar1, errorLugar1, resLugar1);
    updateFieldUI(inputPartido1, errorPartido1, resPartido1);
    updateFieldUI(inputDelito1, errorDelito1, resDelito1);
    updateFieldUI(inputFecha1, errorFecha1, resFecha1);
    updateFieldUI(inputInfo1, errorInfo1, resInfo1);

    updateFieldUI(inputId2, errorId2, resId2);
    updateFieldUI(inputLugar2, errorLugar2, resLugar2);
    updateFieldUI(inputPartido2, errorPartido2, resPartido2);
    updateFieldUI(inputDelito2, errorDelito2, resDelito2);
    updateFieldUI(inputFecha2, errorFecha2, resFecha2);
    updateFieldUI(inputInfo2, errorInfo2, resInfo2);

    const isValid = resId1.valid && resLugar1.valid && resPartido1.valid && resDelito1.valid && resFecha1.valid && resInfo1.valid &&
                    resId2.valid && resLugar2.valid && resPartido2.valid && resDelito2.valid && resFecha2.valid && resInfo2.valid;

    if (!isValid) {
      resultSection.classList.add('hidden');
      return;
    }

    const payload = {
      id1: valId1, lugar1: valLugar1, partido1: valPartido1, delito1: valDelito1, fecha1: valFecha1, info1: valInfo1,
      id2: valId2, lugar2: valLugar2, partido2: valPartido2, delito2: valDelito2, fecha2: valFecha2, info2: valInfo2
    };

    outputMessage.textContent = buildTemplate(payload);
    resultSection.classList.remove('hidden');
    resultSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  // Copiar al Portapapeles
  btnCopy.addEventListener('click', async () => {
    const textToCopy = outputMessage.textContent;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(textToCopy);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = textToCopy;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }

      toast.classList.remove('hidden');
      setTimeout(() => {
        toast.classList.add('hidden');
      }, 3000);

    } catch (err) {
      alert('Error al intentar copiar el mensaje al portapapeles.');
    }
  });

  // Nuevo Análisis / Limpiar
  btnReset.addEventListener('click', () => {
    const hasData = inputId1.value || inputId2.value || inputInfo1.value || inputInfo2.value ||
                    inputLugar1.value || inputLugar2.value || inputDelito1.value || inputDelito2.value ||
                    inputPartido1.value || inputPartido2.value;

    if (hasData) {
      const confirmReset = confirm('¿Desea limpiar todos los campos y comenzar un nuevo análisis?');
      if (!confirmReset) return;
    }

    form.reset();

    clearValidationUI(inputId1, errorId1);
    clearValidationUI(inputLugar1, errorLugar1);
    clearValidationUI(inputPartido1, errorPartido1);
    clearValidationUI(inputDelito1, errorDelito1);
    clearValidationUI(inputFecha1, errorFecha1);
    clearValidationUI(inputInfo1, errorInfo1);

    clearValidationUI(inputId2, errorId2);
    clearValidationUI(inputLugar2, errorLugar2);
    clearValidationUI(inputPartido2, errorPartido2);
    clearValidationUI(inputDelito2, errorDelito2);
    clearValidationUI(inputFecha2, errorFecha2);
    clearValidationUI(inputInfo2, errorInfo2);

    resultSection.classList.add('hidden');
    toast.classList.add('hidden');
    outputMessage.textContent = '';

    inputId1.focus();
  });

});